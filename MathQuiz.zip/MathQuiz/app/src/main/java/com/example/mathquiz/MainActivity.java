package com.example.mathquiz;
/**
 * Subject: Math Quiz App
 * Designed and Developed by: Yousef Emadi
 * Date: 18-SEP-2021
 */

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, TextWatcher {


    final static int REQUEST_NAME = 1;
    /**
     * Variables
     */
    // android vars
    TextView txtTitle, txtAnswer;
    TextView textQuestion;
    Button btnGenerate, btnValidate, btnClear, btnScore, btnFinish,
            btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn0,
            btnComma, btnMinus;
    // Question obj vars
    String description;
    double correctAnswer;
    double userAnswer;
    boolean isRight = false;
    // User Obj vars
    ArrayList<Question> questions;
    int score;
    // counter vars to calc user score
    int questionCounter, rightCounter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initialize();
    }

    private void initialize() {
        txtTitle = findViewById(R.id.txtTitle);
        textQuestion = findViewById(R.id.txtQuestion);

        txtAnswer = findViewById(R.id.txtAnswer);
        txtAnswer.addTextChangedListener(this);


        initializeButtons();

        questions = new ArrayList<>();

        questionCounter = 0;
        rightCounter = 0;
    }


    @SuppressLint("SetTextI18n")
    private void initializeButtons() {
        btnGenerate = findViewById(R.id.btnGenerate);
        btnGenerate.setOnClickListener(this);

        btnValidate = findViewById(R.id.btnValidate);
        btnValidate.setOnClickListener(this);
        btnValidate.setEnabled(false);

        btnClear = findViewById(R.id.btnClear);
        btnClear.setOnClickListener(this);

        btnScore = findViewById(R.id.btnScore);
        btnScore.setOnClickListener(this);

        btnFinish = findViewById(R.id.btnFinish);
        btnFinish.setOnClickListener(this);

        btn1 = findViewById(R.id.button_1);
        btn1.setOnClickListener(v -> txtAnswer.setText(txtAnswer.getText() + "1"));

        btn2 = findViewById(R.id.button_2);
        btn2.setOnClickListener(v -> txtAnswer.setText(txtAnswer.getText() + "2"));

        btn3 = findViewById(R.id.button_3);
        btn3.setOnClickListener(v -> txtAnswer.setText(txtAnswer.getText() + "3"));

        btn4 = findViewById(R.id.button_4);
        btn4.setOnClickListener(v -> txtAnswer.setText(txtAnswer.getText() + "4"));

        btn5 = findViewById(R.id.button_5);
        btn5.setOnClickListener(v -> txtAnswer.setText(txtAnswer.getText() + "5"));

        btn6 = findViewById(R.id.button_6);
        btn6.setOnClickListener(v -> txtAnswer.setText(txtAnswer.getText() + "6"));

        btn7 = findViewById(R.id.button_7);
        btn7.setOnClickListener(v -> txtAnswer.setText(txtAnswer.getText() + "7"));

        btn8 = findViewById(R.id.button_8);
        btn8.setOnClickListener(v -> txtAnswer.setText(txtAnswer.getText() + "8"));

        btn9 = findViewById(R.id.button_9);
        btn9.setOnClickListener(v -> txtAnswer.setText(txtAnswer.getText() + "9"));

        btn0 = findViewById(R.id.button_0);
        btn0.setOnClickListener(v -> txtAnswer.setText(txtAnswer.getText() + "0"));

        btnComma = findViewById(R.id.button_comma);
        btnComma.setOnClickListener(v -> {
            txtAnswer.setText(txtAnswer.getText() + ".");
            btnComma.setEnabled(false);
        });

        btnMinus = findViewById(R.id.button_minus);
        btnMinus.setOnClickListener(v -> txtAnswer.setText(txtAnswer.getText() + "-"));
    }


    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            // operation buttons
            case R.id.btnGenerate:
                doGenerate();
                break;
            case R.id.btnValidate:
                doValidate();
                break;
            case R.id.btnClear:
                doClear();
                break;
            case R.id.btnScore:
                doScore();
                break;
            case R.id.btnFinish:
                doFinish();
                break;
        }
    }

    private void doGenerate() {

        // clean start on user display
        doClear();

        //create a new question obj
        Random random = new Random();
        int num1 = random.nextInt(10);
        int num2 = random.nextInt(10);

        //random operation
        int operation = random.nextInt(4) + 1;
        switch (operation) {
            case (1):
                description = num1 + " + " + num2;
                correctAnswer = num1 + num2;
                break;
            case (2):
                description = num1 + " - " + num2;
                correctAnswer = num1 - num2;
                break;
            case (3):
                description = num1 + " * " + num2;
                correctAnswer = num1 * num2;
                break;
            case (4):
                //to avoid divide by zero
                while (num2 == 0) {
                    num2 = random.nextInt(10);
                }
                description = num1 + " / " + num2;
                correctAnswer = num1 / num2;
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + operation);
        }

        questionCounter++;
        // show the question description to user
        textQuestion.setText(description);
        //disable Generate btn until any answer from the user
        btnGenerate.setEnabled(false);
    }

    private void doValidate() {
        if (userAnswer == correctAnswer) {
            rightCounter++;
            isRight = true;
            textQuestion.setText(R.string.bravo);
        } else {
            textQuestion.setText(R.string.wrong);
        }

        // Create a question object
        Question question = new Question(description, correctAnswer, userAnswer, isRight);

        //add to ArrayList
        questions.add(question);

        // reset everything for the next question
        doClear();
        isRight = false;
        description = null;
        btnValidate.setEnabled(false);
        btnGenerate.setEnabled(true);
    }

    private void doClear() {
        txtAnswer.setText(null);

        // reset buttons' state to default
        btnValidate.setEnabled(false);
        btnComma.setEnabled(true);
        btnMinus.setEnabled(true);
    }

    private void doScore() {

        // to avoid divide by zero
        if (questionCounter == 0) score = 0;
        else score = (int) rightCounter * 100 / questionCounter;


        makeBundle();

        // reset all counters after making bundle package to send to the next activity
        rightCounter = 0;
        questionCounter = 0;
        questions.clear();
    }

    private void doFinish() {
        finish();
    }

    public void makeBundle() {

        User user = new User("currentUser", questions, rightCounter, score);

        Bundle bundle = new Bundle();
        bundle.putSerializable("bundleExtra", user);

        Intent intent = new Intent(this, ResultActivity.class);
        intent.putExtra("intentExtra", bundle);
        startActivityForResult(intent, REQUEST_NAME);
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        // to disable minus button after the very first change in editText for answer
        btnMinus.setEnabled(false);
    }

    @Override
    public void afterTextChanged(Editable editable) {
        try {
            userAnswer = Double.parseDouble(txtAnswer.getText().toString());
            if (description != null) btnValidate.setEnabled(true);
        } catch (Exception e) {
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_NAME && resultCode == RESULT_OK) {
            String str = "Nice try " + (data != null ? data.getStringExtra("username") : "") + "! last score: " + score + "%";
            // to keep the font size proper with the long names
            if (str.length() > 30) txtTitle.setTextSize(25 - (str.length() - 30));
            System.out.println(str.length());
            txtTitle.setText(str);
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_option, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Toast.makeText(this, "Selected Language: " + item.getTitle(), Toast.LENGTH_SHORT).show();
        switch (item.getItemId()) {
            case R.id.langEng:
                languageChanger("en");
                finish();
                startActivity(getIntent());
                return true;

            case R.id.langFra:
                languageChanger("fr");
                finish();
                startActivity(getIntent());
                return true;

            case R.id.langPer:
                languageChanger("fa");
                finish();
                startActivity(getIntent());
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void languageChanger(String languageToLoad) {
        Locale locale = new Locale(languageToLoad);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        getBaseContext().getResources().updateConfiguration(config,
                getBaseContext().getResources().getDisplayMetrics());
        this.setContentView(R.layout.activity_main);

    }
}