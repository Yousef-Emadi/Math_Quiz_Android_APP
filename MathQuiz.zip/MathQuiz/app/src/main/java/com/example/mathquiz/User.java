package com.example.mathquiz;
/**
 * Subject: Math Quiz App
 * Designed and Developed by: Yousef Emadi
 * Date: 18-SEP-2021
 */
import androidx.annotation.NonNull;

import java.io.Serializable;
import java.util.ArrayList;

public class User implements Serializable {
    String name;
    ArrayList<Question> questions;
    int rightAnswersCount;
    int score;


    public User(String name, ArrayList<Question> questions, int rightAnswersCount, int score) {
        this.name = name;
        this.questions = questions;
        this.rightAnswersCount = rightAnswersCount;
        this.score = score;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @NonNull
    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", questions=" + questions +
                ", rightCounter=" + rightAnswersCount +
                ", score=" + score +
                '}';
    }
}
