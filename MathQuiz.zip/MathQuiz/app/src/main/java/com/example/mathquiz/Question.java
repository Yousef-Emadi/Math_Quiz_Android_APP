package com.example.mathquiz;
/**
 * Subject: Math Quiz App
 * Designed and Developed by: Yousef Emadi
 * Date: 18-SEP-2021
 */
import androidx.annotation.NonNull;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.Objects;

public class Question implements Serializable, Comparable {
    String description;
    double correctAnswer;
    double userAnswer;
    boolean isRight;


    public Question(String description, double correctAnswer, double userAnswer, boolean isRight) {
        this.description = description;
        this.correctAnswer = correctAnswer;
        this.userAnswer = userAnswer;
        this.isRight = isRight;
    }

    @NonNull
    @Override
    public String toString() {

        DecimalFormat decForm1 = new DecimalFormat();
        DecimalFormat decForm2 = new DecimalFormat("0.#");
        decForm1.setDecimalSeparatorAlwaysShown(false);
        decForm1.setGroupingUsed(false);

        String res = isRight ? "correct" : "wrong";

        String str = description + " ? \n" +
                "Your answer " + decForm1.format(userAnswer) + " was " + res;

        if (!isRight) str = str + "\nCorrect answer is " + decForm2.format(correctAnswer);

        return str;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Question question = (Question) o;
        return Double.compare(question.correctAnswer, correctAnswer) == 0 && Double.compare(question.userAnswer, userAnswer) == 0 && isRight == question.isRight && Objects.equals(description, question.description);
    }

    @Override
    public int hashCode() {
        return Objects.hash(description, correctAnswer, userAnswer, isRight);
    }


    @Override
    public int compareTo(Object o) {
        return 0;
    }
}


