package com.example.mathquiz;
/**
 * Subject: Math Quiz App
 * Designed and Developed by: Yousef Emadi
 * Date: 18-SEP-2021
 */
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;


public class ResultActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener {

    /**
     * Variables
     */
    Spinner spinner;
    ListView listView;
    Button btnBack;
    EditText txtUsername;
    TextView txtTotalRights, txtTotalWrongs, txtScore;

    User userObj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        initialize();
    }

    @SuppressLint("SetTextI18n")
    private void initialize() {

        Intent intent = getIntent();
        Bundle bundle = intent.getBundleExtra("intentExtra");
        userObj = (User) (bundle.getSerializable("bundleExtra"));

        txtUsername = findViewById(R.id.editTextUsername);

        txtTotalRights = findViewById(R.id.textTotalRightAnswers);
        txtTotalRights.setText(String.valueOf(userObj.rightAnswersCount));

        txtTotalWrongs = findViewById(R.id.textTotalWrongAnswers);
        txtTotalWrongs.setText(String.valueOf(userObj.questions.size() - userObj.rightAnswersCount));

        txtScore = findViewById(R.id.textScore);
        txtScore.setText(userObj.score + "%");

        listView = findViewById(R.id.listView);

        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(this);

        spinner = findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(this);

        //initialize the spinner
        ArrayAdapter adapter = ArrayAdapter.createFromResource(
                this,
                R.array.spinnerOptions,
                android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btnBack) doBack();
    }

    private void doBack() {
        String username = txtUsername.getText().toString();
        // to discard empty value for the username
        if (username.length() > 0) {
            Intent intent = new Intent();
            intent.putExtra("username", username);
            setResult(RESULT_OK, intent);
            // update username in userObj for saving user object and any further usage such as high score ranking
            userObj.name = username;
        }
        finish();
    }

    @RequiresApi(api = Build.VERSION_CODES.R)
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

        switch (i) {
            case 0:
                showAll();
                break;
            case 1:
                showOnlyRightAnswers();
                break;
            case 2:
                showOnlyWrongAnswers();
                break;
            case 3:
                showASCbyRightAnswers();
                break;
            case 4:
                showASCbyWrongAnswers();
                break;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.R)
    private void showAll() {

        listView.setAdapter(adapterMaker(userObj.questions));
    }

    private void showOnlyRightAnswers() {
        ArrayList<Question> tempArray = new ArrayList<>();
        for (Question q : userObj.questions
        ) {
            if (q.isRight) tempArray.add(q);
        }

        listView.setAdapter(adapterMaker(tempArray));
    }

    private void showOnlyWrongAnswers() {
        ArrayList<Question> tempArray = new ArrayList<>();
        for (Question q : userObj.questions
        ) {
            if (!q.isRight) tempArray.add(q);
        }

        listView.setAdapter(adapterMaker(tempArray));
    }

    private void showASCbyRightAnswers() {
        Collections.sort(userObj.questions, (q1, q2) -> Boolean.compare(q1.isRight, q2.isRight));
        Collections.reverse(userObj.questions);
        listView.setAdapter(adapterMaker(userObj.questions));
    }

    private void showASCbyWrongAnswers() {
        Collections.sort(userObj.questions, (q1, q2) -> Boolean.compare(q1.isRight, q2.isRight));
        listView.setAdapter(adapterMaker(userObj.questions));
    }


    public ArrayAdapter<Question> adapterMaker(ArrayList<Question> aList) {

        return new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                aList);
    }


    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
    }

}